﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using System.Collections.Generic;

namespace WFA_PicDeal0003CutPicture01
{
    public partial class frm_CutPictureWalking : Form
    {
        public string m_sFileType = "";
        public string m_sFileName = "";
        public int m_iPicCount = 0;
        private Boolean m_bTrace = false;
        private int m_iBeginX = 0;
        private int m_iBeginY = 0;

        public frm_CutPictureWalking()
        {
            InitializeComponent();

            m_sFileType = "";
            m_sFileName = "";
            m_iPicCount = 0;
            m_bTrace = false;
            m_iBeginX = 0;
            m_iBeginY = 0;

            tbx_Width.Text = "48";
            tbx_Height.Text = "48";
        }//public frm_CutPictureWalking()

        private void btn_Close_Click(object sender, EventArgs e)
        {
            Close();
        }//private void btn_Close_Click(object sender, EventArgs e)

        private void btn_Open_Click(object sender, EventArgs e)
        {
            if(ofd_Open.ShowDialog() == System.Windows.Forms.DialogResult.OK)
            {
                if(ofd_Open.FileName.Trim() != "")
                {
                    m_sFileName = ofd_Open.FileName;
                    m_sFileType = ofd_Open.DefaultExt;

                    pbx_Source.Load(m_sFileName);
                }
            }//if(ofd_Open.ShowDialog() == System.Windows.Forms.DialogResult.OK)
        }//private void btn_Open_Click(object sender, EventArgs e)

        private void tbx_Width_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9') //Key is a digital
            {
                e.Handled = true;
            }
        }//private void tbx_Width_KeyPress(object sender, KeyPressEventArgs e)

        private void tbx_Height_KeyPress(object sender, KeyPressEventArgs e)
        {
            if (e.KeyChar < '0' || e.KeyChar > '9') //Key is a digital
            {
                e.Handled = true;
            }
        }//private void tbx_Height_KeyPress(object sender, KeyPressEventArgs e)

        private void cbx_Set_CheckedChanged(object sender, EventArgs e)
        {
            if(cbx_Set.Checked)
            {
                gb_Walk.Enabled = true;
                gb_Select.Enabled = false;

                /*
                lbl_Width.Enabled = true;
                lbl_Height.Enabled = true;
                tbx_Width.Enabled = true;
                tbx_Height.Enabled = true;
                 */
            }
            else
            {
                gb_Walk.Enabled = false;
                gb_Select.Enabled = true;

                /*
                lbl_Width.Enabled = false;
                lbl_Height.Enabled = false;
                tbx_Width.Enabled = false;
                tbx_Height.Enabled = false;
                 */
            }//if(cbx_Set.Checked)
            
        }//private void cbx_Set_CheckedChanged(object sender, EventArgs e)

        private void pbx_0101_Click(object sender, EventArgs e)
        {
            m_iPicCount = 0;//Setting goal image
        }//private void pbx_0101_Click(object sender, MouseEventArgs e)

        private void pbx_0102_Click(object sender, EventArgs e)
        {
            m_iPicCount = 1;//Setting goal image
        }//private void pbx_0102_Click(object sender, MouseEventArgs e)

        private void pbx_0103_Click(object sender, EventArgs e)
        {
            m_iPicCount = 2;//Setting goal image
        }//private void pbx_0103_Click(object sender, MouseEventArgs e)

        private void pbx_0201_Click(object sender, EventArgs e)
        {
            m_iPicCount = 3;//Setting goal image
        }//private void pbx_0201_Click(object sender, MouseEventArgs e)

        private void pbx_0202_Click(object sender, EventArgs e)
        {
            m_iPicCount = 4;//Setting goal image
        }//private void pbx_0202_Click(object sender, MouseEventArgs e)

        private void pbx_0203_Click(object sender, EventArgs e)
        {
            m_iPicCount = 5;//Setting goal image
        }//private void pbx_0203_Click(object sender, MouseEventArgs e)

        private void pbx_0301_Click(object sender, EventArgs e)
        {
            m_iPicCount = 6;//Setting goal image
        }//private void pbx_0301_Click(object sender, MouseEventArgs e)

        private void pbx_0302_Click(object sender, EventArgs e)
        {
            m_iPicCount = 7;//Setting goal image
        }//private void pbx_0302_Click(object sender, MouseEventArgs e)

        private void pbx_0303_Click(object sender, EventArgs e)
        {
            m_iPicCount = 8;//Setting goal image
        }//private void pbx_0303_Click(object sender, MouseEventArgs e)

        private void pbx_0401_Click(object sender, EventArgs e)
        {
            m_iPicCount = 9;//Setting goal image
        }//private void pbx_0401_Click(object sender, MouseEventArgs e)

        private void pbx_0402_Click(object sender, EventArgs e)
        {
            m_iPicCount = 10;//Setting goal image
        }//private void pbx_0402_Click(object sender, MouseEventArgs e)

        private void pbx_0403_Click(object sender, EventArgs e)
        {
            m_iPicCount = 11;//Setting goal image
        }//private void pbx_0403_Click(object sender, MouseEventArgs e)

        private void pbx_Source_MouseClick(object sender, MouseEventArgs e)
        {
            //MessageBox.Show(e.X.ToString()+";"+e.Y.ToString());
            if ((cbx_Set.Checked)&&(pbx_Source.Image != null))
            {
                int l_iBeginX = 0;
                int l_iBeginY = 0;
                int l_iWidth = 48;
                int l_iHeight = 48;

                //Get image begin point and size
                if (tbx_Width.Text.Trim().Length > 0)
                {
                    l_iWidth = Convert.ToInt32(tbx_Width.Text);
                    if (l_iWidth > pbx_Source.Width) { l_iWidth = pbx_Source.Width;  }
                }

                if ((e.X + l_iWidth) > pbx_Source.Width) { l_iBeginX = pbx_Source.Width - l_iWidth; } else { l_iBeginX = e.X; }

                if (tbx_Height.Text.Trim().Length > 0)
                {
                    l_iHeight = Convert.ToInt32(tbx_Height.Text);
                    if (l_iHeight > pbx_Source.Height) { l_iHeight = pbx_Source.Height; }
                }
                if ((e.Y + l_iHeight) > pbx_Source.Height) { l_iBeginY = pbx_Source.Height - l_iHeight; } else { l_iBeginY = e.Y; }

                switch (m_iPicCount)
                {
                    case 0:
                        pbx_0101.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp00 = Graphics.FromImage(pbx_0101.Image);
                        l_gTemp00.Clear(Color.Transparent);
                        l_gTemp00.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp00.Dispose();
                        break;
                    case 1:
                        pbx_0102.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp01 = Graphics.FromImage(pbx_0102.Image);
                        l_gTemp01.Clear(Color.Transparent);
                        l_gTemp01.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp01.Dispose();
                        break;
                    case 2:
                        pbx_0103.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp02 = Graphics.FromImage(pbx_0103.Image);
                        l_gTemp02.Clear(Color.Transparent);
                        l_gTemp02.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp02.Dispose();
                        break;
                    case 3:
                        pbx_0201.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp03 = Graphics.FromImage(pbx_0201.Image);
                        l_gTemp03.Clear(Color.Transparent);
                        l_gTemp03.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp03.Dispose();
                        break;
                    case 4:
                        pbx_0202.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp04 = Graphics.FromImage(pbx_0202.Image);
                        l_gTemp04.Clear(Color.Transparent);
                        l_gTemp04.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp04.Dispose();
                        break;
                    case 5:
                        pbx_0203.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp05 = Graphics.FromImage(pbx_0203.Image);
                        l_gTemp05.Clear(Color.Transparent);
                        l_gTemp05.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp05.Dispose();
                        break;
                    case 6:
                        pbx_0301.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp06 = Graphics.FromImage(pbx_0301.Image);
                        l_gTemp06.Clear(Color.Transparent);
                        l_gTemp06.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp06.Dispose();
                       break;
                    case 7:
                        pbx_0302.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp07 = Graphics.FromImage(pbx_0302.Image);
                        l_gTemp07.Clear(Color.Transparent);
                        l_gTemp07.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp07.Dispose();
                        break;
                    case 8:
                        pbx_0303.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp08 = Graphics.FromImage(pbx_0303.Image);
                        l_gTemp08.Clear(Color.Transparent);
                        l_gTemp08.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp08.Dispose();
                        break;
                    case 9:
                        pbx_0401.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp09 = Graphics.FromImage(pbx_0401.Image);
                        l_gTemp09.Clear(Color.Transparent);
                        l_gTemp09.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp09.Dispose();
                        break;
                    case 10:
                        pbx_0402.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp10 = Graphics.FromImage(pbx_0402.Image);
                        l_gTemp10.Clear(Color.Transparent);
                        l_gTemp10.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp10.Dispose();
                        break;
                    case 11:
                        pbx_0403.Image = new Bitmap(l_iWidth, l_iHeight);
                        Graphics l_gTemp11 = Graphics.FromImage(pbx_0403.Image);
                        l_gTemp11.Clear(Color.Transparent);
                        l_gTemp11.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                        l_gTemp11.Dispose();
                        break;
                    default:
                        break;
                }//switch (m_iPicCount)
                if (m_iPicCount < 11) { m_iPicCount += 1; }
                
            }
        }//private void pbx_Source_MouseClick(object sender, MouseEventArgs e)

        private void pbx_Source_MouseDown(object sender, MouseEventArgs e)
        {
            if ((!cbx_Set.Checked)&&(pbx_Source.Image != null))
            {
                m_iBeginX = e.X;
                m_iBeginY = e.Y;
                m_bTrace = true;
            }//if (!cbx_Set.Checked)

        }//private void pbx_Source_MouseDown(object sender, MouseEventArgs e)

        private void pbx_Source_MouseUp(object sender, MouseEventArgs e)
        {
            if ((!cbx_Set.Checked) && (m_bTrace) && (m_iBeginX != e.X) && (m_iBeginY != e.Y) && (pbx_Source.Image != null))
            {
                int l_iBeginX = 0;
                int l_iBeginY = 0;
                int l_iWidth = 0;
                int l_iHeight = 0;
                m_bTrace = false;

                //Get beginning X and width
                if (m_iBeginX < e.X)
                {
                    l_iWidth = e.X - m_iBeginX;
                    l_iBeginX = m_iBeginX;
                }
                else
                {
                    l_iWidth = m_iBeginX - e.X;
                    l_iBeginX = e.X;
                }//if (m_iBeginX < e.X)


                //Get beginning Y and height
                if (m_iBeginY < e.Y)
                {
                    l_iHeight = e.Y - m_iBeginY;
                    l_iBeginY = m_iBeginY;
                }
                else
                {
                    l_iHeight = m_iBeginY - e.Y;
                    l_iBeginY = e.Y;
                }//if (m_iBeginY < e.Y)

                //Draw the selected part
                pbx_MouseCut.Image = new Bitmap(l_iWidth, l_iHeight);
                Graphics l_gTemp00 = Graphics.FromImage(pbx_MouseCut.Image);
                l_gTemp00.Clear(Color.Transparent);
                l_gTemp00.DrawImage(pbx_Source.Image, 0, 0, new Rectangle(l_iBeginX, l_iBeginY, l_iWidth, l_iHeight), GraphicsUnit.Pixel);
                l_gTemp00.Dispose();

            }//if ((!cbx_Set.Checked) && (m_bTrace)&&(m_iBeginX == e.X)&&(m_iBeginY == e.Y))
        }

        private void btn_Save_Click(object sender, EventArgs e)
        {
            if (cbx_Set.Checked)
            {
                //Build a new fold
                string l_sPathname = Path.Combine(Directory.GetCurrentDirectory(), DateTime.Now.ToString("yyyyMMddhhmmsszzz"));
                string l_sFileName = "";
                
                if (!Directory.Exists(l_sPathname))
                {
                    Directory.CreateDirectory(l_sPathname);
                }

                if (pbx_0101.Image != null)
                {
                    l_sFileName = l_sPathname + "01.PNG";
                    pbx_0101.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)

                if (pbx_0102.Image != null)
                {
                    l_sFileName = l_sPathname + "02.PNG";
                    pbx_0102.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)

                if (pbx_0103.Image != null)
                {
                    l_sFileName = l_sPathname + "03.PNG";
                    pbx_0103.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)

                if (pbx_0201.Image != null)
                {
                    l_sFileName = l_sPathname + "04.PNG";
                    pbx_0201.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)


                if (pbx_0202.Image != null)
                {
                    l_sFileName = l_sPathname + "05.PNG";
                    pbx_0202.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)

                if (pbx_0203.Image != null)
                {
                    l_sFileName = l_sPathname + "06.PNG";
                    pbx_0203.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)


                if (pbx_0301.Image != null)
                {
                    l_sFileName = l_sPathname + "07.PNG";
                    pbx_0301.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)

                if (pbx_0302.Image != null)
                {
                    l_sFileName = l_sPathname + "08.PNG";
                    pbx_0302.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)

                if (pbx_0303.Image != null)
                {
                    l_sFileName = l_sPathname + "09.PNG";
                    pbx_0303.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)

                if (pbx_0401.Image != null)
                {
                    l_sFileName = l_sPathname + "10.PNG";
                    pbx_0401.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)


                if (pbx_0402.Image != null)
                {
                    l_sFileName = l_sPathname + "11.PNG";
                    pbx_0402.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)

                if (pbx_0403.Image != null)
                {
                    l_sFileName = l_sPathname + "12.PNG";
                    pbx_0403.Image.Save(l_sFileName, System.Drawing.Imaging.ImageFormat.Png);
                }//if (pbx_0101.Image != null)

            }
            else
            {
                if (pbx_MouseCut.Image == null)
                {
                    MessageBox.Show("The picture is empty. Please build the picture first.");
                    return;
                }//if (pbx_Composed.Image == null)

                string l_sFilename = DateTime.Now.ToString("yyyyMMddhhmmss") + ".PNG";//Default file name
                if (sfd_Save.ShowDialog() == DialogResult.OK)
                {
                    l_sFilename = sfd_Save.FileName;
                }//if (sfd_Composed.ShowDialog() == DialogResult.OK)

                if (l_sFilename.ToUpper().IndexOf(".PNG") < 0)
                {
                    l_sFilename += ".Png";
                }//if(l_sFilename.ToUpper().IndexOf(".PNG") < 0)

                pbx_MouseCut.Image.Save(l_sFilename, System.Drawing.Imaging.ImageFormat.Png);
                MessageBox.Show("This picture is saved as " + l_sFilename + ".");
            }//if (cbx_Set.Checked)
        }//private void pbx_Source_MouseUp(object sender, MouseEventArgs e)

    }
}
