﻿namespace WFA_PicDeal0003CutPicture01
{
    partial class frm_CutPictureWalking
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.ofd_Open = new System.Windows.Forms.OpenFileDialog();
            this.sfd_Save = new System.Windows.Forms.SaveFileDialog();
            this.textBox1 = new System.Windows.Forms.TextBox();
            this.gbx_Button = new System.Windows.Forms.GroupBox();
            this.btn_Save = new System.Windows.Forms.Button();
            this.btn_Open = new System.Windows.Forms.Button();
            this.btn_Close = new System.Windows.Forms.Button();
            this.pbx_Source = new System.Windows.Forms.PictureBox();
            this.lbl_Width = new System.Windows.Forms.Label();
            this.lbl_Height = new System.Windows.Forms.Label();
            this.tbx_Width = new System.Windows.Forms.TextBox();
            this.tbx_Height = new System.Windows.Forms.TextBox();
            this.cbx_Set = new System.Windows.Forms.CheckBox();
            this.gb_Walk = new System.Windows.Forms.GroupBox();
            this.pbx_0401 = new System.Windows.Forms.PictureBox();
            this.pbx_0301 = new System.Windows.Forms.PictureBox();
            this.pbx_0201 = new System.Windows.Forms.PictureBox();
            this.pbx_0102 = new System.Windows.Forms.PictureBox();
            this.pbx_0103 = new System.Windows.Forms.PictureBox();
            this.pbx_0202 = new System.Windows.Forms.PictureBox();
            this.pbx_0203 = new System.Windows.Forms.PictureBox();
            this.pbx_0302 = new System.Windows.Forms.PictureBox();
            this.pbx_0402 = new System.Windows.Forms.PictureBox();
            this.pbx_0403 = new System.Windows.Forms.PictureBox();
            this.pbx_0303 = new System.Windows.Forms.PictureBox();
            this.pbx_0101 = new System.Windows.Forms.PictureBox();
            this.gb_Select = new System.Windows.Forms.GroupBox();
            this.pbx_MouseCut = new System.Windows.Forms.PictureBox();
            this.gbx_Button.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Source)).BeginInit();
            this.gb_Walk.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0401)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0301)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0201)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0102)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0103)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0202)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0203)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0302)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0402)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0403)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0303)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0101)).BeginInit();
            this.gb_Select.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_MouseCut)).BeginInit();
            this.SuspendLayout();
            // 
            // ofd_Open
            // 
            this.ofd_Open.FileName = "Open Picture";
            this.ofd_Open.Filter = "All File(*.*)|*.*|PNG File(*.png)|*.png|JPG File(*.jpg)|*.jpg|BMP File(*.bmp)|*.b" +
    "mp";
            // 
            // sfd_Save
            // 
            this.sfd_Save.Filter = "All File(*.*)|*.*|PNG File(*.png)|*.png";
            // 
            // textBox1
            // 
            this.textBox1.Location = new System.Drawing.Point(-4, 709);
            this.textBox1.Name = "textBox1";
            this.textBox1.Size = new System.Drawing.Size(1000, 21);
            this.textBox1.TabIndex = 0;
            // 
            // gbx_Button
            // 
            this.gbx_Button.Controls.Add(this.btn_Save);
            this.gbx_Button.Controls.Add(this.btn_Open);
            this.gbx_Button.Controls.Add(this.btn_Close);
            this.gbx_Button.Location = new System.Drawing.Point(-4, 642);
            this.gbx_Button.Name = "gbx_Button";
            this.gbx_Button.Size = new System.Drawing.Size(1000, 61);
            this.gbx_Button.TabIndex = 1;
            this.gbx_Button.TabStop = false;
            // 
            // btn_Save
            // 
            this.btn_Save.Location = new System.Drawing.Point(106, 11);
            this.btn_Save.Name = "btn_Save";
            this.btn_Save.Size = new System.Drawing.Size(90, 23);
            this.btn_Save.TabIndex = 2;
            this.btn_Save.Text = "Save As";
            this.btn_Save.UseVisualStyleBackColor = true;
            this.btn_Save.Click += new System.EventHandler(this.btn_Save_Click);
            // 
            // btn_Open
            // 
            this.btn_Open.Location = new System.Drawing.Point(10, 11);
            this.btn_Open.Name = "btn_Open";
            this.btn_Open.Size = new System.Drawing.Size(90, 23);
            this.btn_Open.TabIndex = 1;
            this.btn_Open.Text = "Open Picture";
            this.btn_Open.UseVisualStyleBackColor = true;
            this.btn_Open.Click += new System.EventHandler(this.btn_Open_Click);
            // 
            // btn_Close
            // 
            this.btn_Close.Location = new System.Drawing.Point(919, 32);
            this.btn_Close.Name = "btn_Close";
            this.btn_Close.Size = new System.Drawing.Size(75, 23);
            this.btn_Close.TabIndex = 0;
            this.btn_Close.Text = "Close";
            this.btn_Close.UseVisualStyleBackColor = true;
            this.btn_Close.Click += new System.EventHandler(this.btn_Close_Click);
            // 
            // pbx_Source
            // 
            this.pbx_Source.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_Source.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_Source.Location = new System.Drawing.Point(6, 3);
            this.pbx_Source.Name = "pbx_Source";
            this.pbx_Source.Size = new System.Drawing.Size(640, 640);
            this.pbx_Source.TabIndex = 2;
            this.pbx_Source.TabStop = false;
            this.pbx_Source.MouseClick += new System.Windows.Forms.MouseEventHandler(this.pbx_Source_MouseClick);
            this.pbx_Source.MouseDown += new System.Windows.Forms.MouseEventHandler(this.pbx_Source_MouseDown);
            this.pbx_Source.MouseUp += new System.Windows.Forms.MouseEventHandler(this.pbx_Source_MouseUp);
            // 
            // lbl_Width
            // 
            this.lbl_Width.AutoSize = true;
            this.lbl_Width.Location = new System.Drawing.Point(686, 593);
            this.lbl_Width.Name = "lbl_Width";
            this.lbl_Width.Size = new System.Drawing.Size(41, 12);
            this.lbl_Width.TabIndex = 4;
            this.lbl_Width.Text = "Width:";
            // 
            // lbl_Height
            // 
            this.lbl_Height.AutoSize = true;
            this.lbl_Height.Location = new System.Drawing.Point(686, 621);
            this.lbl_Height.Name = "lbl_Height";
            this.lbl_Height.Size = new System.Drawing.Size(47, 12);
            this.lbl_Height.TabIndex = 5;
            this.lbl_Height.Text = "Height:";
            // 
            // tbx_Width
            // 
            this.tbx_Width.Enabled = false;
            this.tbx_Width.Location = new System.Drawing.Point(733, 590);
            this.tbx_Width.MaxLength = 6;
            this.tbx_Width.Name = "tbx_Width";
            this.tbx_Width.Size = new System.Drawing.Size(100, 21);
            this.tbx_Width.TabIndex = 6;
            this.tbx_Width.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_Width_KeyPress);
            // 
            // tbx_Height
            // 
            this.tbx_Height.Enabled = false;
            this.tbx_Height.Location = new System.Drawing.Point(733, 618);
            this.tbx_Height.MaxLength = 6;
            this.tbx_Height.Name = "tbx_Height";
            this.tbx_Height.Size = new System.Drawing.Size(100, 21);
            this.tbx_Height.TabIndex = 7;
            this.tbx_Height.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.tbx_Height_KeyPress);
            // 
            // cbx_Set
            // 
            this.cbx_Set.AutoSize = true;
            this.cbx_Set.Checked = true;
            this.cbx_Set.CheckState = System.Windows.Forms.CheckState.Checked;
            this.cbx_Set.Location = new System.Drawing.Point(688, 562);
            this.cbx_Set.Name = "cbx_Set";
            this.cbx_Set.Size = new System.Drawing.Size(72, 16);
            this.cbx_Set.TabIndex = 8;
            this.cbx_Set.Text = "Set Size";
            this.cbx_Set.UseVisualStyleBackColor = true;
            this.cbx_Set.CheckedChanged += new System.EventHandler(this.cbx_Set_CheckedChanged);
            // 
            // gb_Walk
            // 
            this.gb_Walk.Controls.Add(this.pbx_0401);
            this.gb_Walk.Controls.Add(this.pbx_0301);
            this.gb_Walk.Controls.Add(this.pbx_0201);
            this.gb_Walk.Controls.Add(this.pbx_0102);
            this.gb_Walk.Controls.Add(this.pbx_0103);
            this.gb_Walk.Controls.Add(this.pbx_0202);
            this.gb_Walk.Controls.Add(this.pbx_0203);
            this.gb_Walk.Controls.Add(this.pbx_0302);
            this.gb_Walk.Controls.Add(this.pbx_0402);
            this.gb_Walk.Controls.Add(this.pbx_0403);
            this.gb_Walk.Controls.Add(this.pbx_0303);
            this.gb_Walk.Controls.Add(this.pbx_0101);
            this.gb_Walk.Location = new System.Drawing.Point(675, 3);
            this.gb_Walk.Name = "gb_Walk";
            this.gb_Walk.Size = new System.Drawing.Size(218, 253);
            this.gb_Walk.TabIndex = 9;
            this.gb_Walk.TabStop = false;
            // 
            // pbx_0401
            // 
            this.pbx_0401.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0401.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0401.Location = new System.Drawing.Point(6, 182);
            this.pbx_0401.Name = "pbx_0401";
            this.pbx_0401.Size = new System.Drawing.Size(48, 48);
            this.pbx_0401.TabIndex = 15;
            this.pbx_0401.TabStop = false;
            this.pbx_0401.Click += new System.EventHandler(this.pbx_0401_Click);
            // 
            // pbx_0301
            // 
            this.pbx_0301.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0301.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0301.Location = new System.Drawing.Point(6, 128);
            this.pbx_0301.Name = "pbx_0301";
            this.pbx_0301.Size = new System.Drawing.Size(48, 48);
            this.pbx_0301.TabIndex = 14;
            this.pbx_0301.TabStop = false;
            this.pbx_0301.Click += new System.EventHandler(this.pbx_0301_Click);
            // 
            // pbx_0201
            // 
            this.pbx_0201.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0201.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0201.Location = new System.Drawing.Point(6, 74);
            this.pbx_0201.Name = "pbx_0201";
            this.pbx_0201.Size = new System.Drawing.Size(48, 48);
            this.pbx_0201.TabIndex = 13;
            this.pbx_0201.TabStop = false;
            this.pbx_0201.Click += new System.EventHandler(this.pbx_0201_Click);
            // 
            // pbx_0102
            // 
            this.pbx_0102.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0102.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0102.Location = new System.Drawing.Point(76, 20);
            this.pbx_0102.Name = "pbx_0102";
            this.pbx_0102.Size = new System.Drawing.Size(48, 48);
            this.pbx_0102.TabIndex = 12;
            this.pbx_0102.TabStop = false;
            this.pbx_0102.Click += new System.EventHandler(this.pbx_0102_Click);
            // 
            // pbx_0103
            // 
            this.pbx_0103.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0103.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0103.Location = new System.Drawing.Point(144, 20);
            this.pbx_0103.Name = "pbx_0103";
            this.pbx_0103.Size = new System.Drawing.Size(48, 48);
            this.pbx_0103.TabIndex = 11;
            this.pbx_0103.TabStop = false;
            this.pbx_0103.Click += new System.EventHandler(this.pbx_0103_Click);
            // 
            // pbx_0202
            // 
            this.pbx_0202.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0202.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0202.Location = new System.Drawing.Point(76, 74);
            this.pbx_0202.Name = "pbx_0202";
            this.pbx_0202.Size = new System.Drawing.Size(48, 48);
            this.pbx_0202.TabIndex = 10;
            this.pbx_0202.TabStop = false;
            this.pbx_0202.Click += new System.EventHandler(this.pbx_0202_Click);
            // 
            // pbx_0203
            // 
            this.pbx_0203.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0203.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0203.Location = new System.Drawing.Point(144, 74);
            this.pbx_0203.Name = "pbx_0203";
            this.pbx_0203.Size = new System.Drawing.Size(48, 48);
            this.pbx_0203.TabIndex = 9;
            this.pbx_0203.TabStop = false;
            this.pbx_0203.Click += new System.EventHandler(this.pbx_0203_Click);
            // 
            // pbx_0302
            // 
            this.pbx_0302.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0302.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0302.Location = new System.Drawing.Point(76, 128);
            this.pbx_0302.Name = "pbx_0302";
            this.pbx_0302.Size = new System.Drawing.Size(48, 48);
            this.pbx_0302.TabIndex = 8;
            this.pbx_0302.TabStop = false;
            this.pbx_0302.Click += new System.EventHandler(this.pbx_0302_Click);
            // 
            // pbx_0402
            // 
            this.pbx_0402.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0402.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0402.Location = new System.Drawing.Point(76, 182);
            this.pbx_0402.Name = "pbx_0402";
            this.pbx_0402.Size = new System.Drawing.Size(48, 48);
            this.pbx_0402.TabIndex = 7;
            this.pbx_0402.TabStop = false;
            this.pbx_0402.Click += new System.EventHandler(this.pbx_0402_Click);
            // 
            // pbx_0403
            // 
            this.pbx_0403.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0403.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0403.Location = new System.Drawing.Point(144, 182);
            this.pbx_0403.Name = "pbx_0403";
            this.pbx_0403.Size = new System.Drawing.Size(48, 48);
            this.pbx_0403.TabIndex = 6;
            this.pbx_0403.TabStop = false;
            this.pbx_0403.Click += new System.EventHandler(this.pbx_0403_Click);
            // 
            // pbx_0303
            // 
            this.pbx_0303.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0303.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0303.Location = new System.Drawing.Point(144, 128);
            this.pbx_0303.Name = "pbx_0303";
            this.pbx_0303.Size = new System.Drawing.Size(48, 48);
            this.pbx_0303.TabIndex = 5;
            this.pbx_0303.TabStop = false;
            this.pbx_0303.Click += new System.EventHandler(this.pbx_0303_Click);
            // 
            // pbx_0101
            // 
            this.pbx_0101.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_0101.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_0101.Location = new System.Drawing.Point(6, 20);
            this.pbx_0101.Name = "pbx_0101";
            this.pbx_0101.Size = new System.Drawing.Size(48, 48);
            this.pbx_0101.TabIndex = 4;
            this.pbx_0101.TabStop = false;
            this.pbx_0101.Click += new System.EventHandler(this.pbx_0101_Click);
            // 
            // gb_Select
            // 
            this.gb_Select.Controls.Add(this.pbx_MouseCut);
            this.gb_Select.Location = new System.Drawing.Point(675, 262);
            this.gb_Select.Name = "gb_Select";
            this.gb_Select.Size = new System.Drawing.Size(315, 294);
            this.gb_Select.TabIndex = 10;
            this.gb_Select.TabStop = false;
            // 
            // pbx_MouseCut
            // 
            this.pbx_MouseCut.BackColor = System.Drawing.SystemColors.Info;
            this.pbx_MouseCut.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbx_MouseCut.Location = new System.Drawing.Point(6, 20);
            this.pbx_MouseCut.Name = "pbx_MouseCut";
            this.pbx_MouseCut.Size = new System.Drawing.Size(303, 268);
            this.pbx_MouseCut.TabIndex = 0;
            this.pbx_MouseCut.TabStop = false;
            // 
            // frm_CutPictureWalking
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 12F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1008, 729);
            this.Controls.Add(this.gb_Select);
            this.Controls.Add(this.gb_Walk);
            this.Controls.Add(this.cbx_Set);
            this.Controls.Add(this.tbx_Height);
            this.Controls.Add(this.tbx_Width);
            this.Controls.Add(this.lbl_Height);
            this.Controls.Add(this.lbl_Width);
            this.Controls.Add(this.pbx_Source);
            this.Controls.Add(this.gbx_Button);
            this.Controls.Add(this.textBox1);
            this.Name = "frm_CutPictureWalking";
            this.Text = "Cutting Picture";
            this.gbx_Button.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_Source)).EndInit();
            this.gb_Walk.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0401)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0301)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0201)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0102)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0103)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0202)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0203)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0302)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0402)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0403)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0303)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbx_0101)).EndInit();
            this.gb_Select.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.pbx_MouseCut)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.OpenFileDialog ofd_Open;
        private System.Windows.Forms.SaveFileDialog sfd_Save;
        private System.Windows.Forms.TextBox textBox1;
        private System.Windows.Forms.GroupBox gbx_Button;
        private System.Windows.Forms.Button btn_Close;
        private System.Windows.Forms.PictureBox pbx_Source;
        private System.Windows.Forms.Button btn_Open;
        private System.Windows.Forms.Label lbl_Width;
        private System.Windows.Forms.Label lbl_Height;
        private System.Windows.Forms.TextBox tbx_Width;
        private System.Windows.Forms.TextBox tbx_Height;
        private System.Windows.Forms.CheckBox cbx_Set;
        private System.Windows.Forms.GroupBox gb_Walk;
        private System.Windows.Forms.PictureBox pbx_0401;
        private System.Windows.Forms.PictureBox pbx_0301;
        private System.Windows.Forms.PictureBox pbx_0201;
        private System.Windows.Forms.PictureBox pbx_0102;
        private System.Windows.Forms.PictureBox pbx_0103;
        private System.Windows.Forms.PictureBox pbx_0202;
        private System.Windows.Forms.PictureBox pbx_0203;
        private System.Windows.Forms.PictureBox pbx_0302;
        private System.Windows.Forms.PictureBox pbx_0402;
        private System.Windows.Forms.PictureBox pbx_0403;
        private System.Windows.Forms.PictureBox pbx_0303;
        private System.Windows.Forms.PictureBox pbx_0101;
        private System.Windows.Forms.GroupBox gb_Select;
        private System.Windows.Forms.PictureBox pbx_MouseCut;
        private System.Windows.Forms.Button btn_Save;
    }
}

